/* eslint-disable no-unused-vars */
// Copyright (c) 2021 team 10 productions. All rights reserved.
// thanks to fxe for helping me figure out nexuspipe and testing
// v13! v14 is a little weird but support should come soon!

const { REST } = require("@discordjs/rest");
const { Routes } = require("discord-api-types/v9"); // v13

const {
  Client,
  MessageEmbed,
  Intents,
  Collection,
  GatewayIntentBits,
} = require("discord.js");
//const client = new Client({ intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.GuildPresences] });
const client = new Client({
  intents: [
    Intents.FLAGS.GUILDS,
    Intents.FLAGS.GUILD_MESSAGES,
    Intents.FLAGS.GUILD_PRESENCES,
  ],
});

const config = require("./config.json");
const request = require("request");
const path = require("node:path");
const fs = require("fs");
const constants = require("constants");

const commands = [];

client.commands = new Collection();

const commandsPath = path.join(__dirname, "commands");
const commandFiles = fs
  .readdirSync(commandsPath)
  .filter((file) => file.endsWith(".js"));

for (const file of commandFiles) {
  const filePath = path.join(commandsPath, file);
  const command = require(filePath);
  commands.push(command.data.toJSON());
  client.commands.set(command.data.name, command);
}

// How long it should wait until a fetch is made to fetch tickets again
const FETCH_AWAIT = 120000;

const sleep = (time) => new Promise((resolve) => setTimeout(resolve, time));
const fmt_time = (time, isDateHandler) => {
  if (!time) return;
  time += " UTC";

  if (isDateHandler) return new Date(time).getTime() / 1000;
  return time;
};

// strip function to strip tags that tickets have included to actually be readable
const strip_tags = require("html-to-text").compile({
  preserveNewlines: true, // This will cause issues, though to at least get readable ticket output we will keep this here.
});

const defaultHeaders = {
  "User-Agent":
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 13.0; rv:107.0) Gecko/20100101 Firefox/107.0",
  accept: "*\\/*",
  "accept-language": "en-US,en;q=0.9",
  "Accept-Encoding": "gzip, deflate, br",

  authorization: config.dashboardCookie.includes("Bearer ")
    ? config.dashboardCookie
    : "Bearer " + config.dashboardCookie,

  Referer: "https://dashboard.script-ware.com/",
  "Referrer-Policy": "strict-origin-when-cross-origin",
  Origin: "https://dashboard.script-ware.com",

  "content-type": "application/json",
};

if (!fs.existsSync("./tickets.json")) fs.writeFileSync("./tickets.json", "{}");
let tickets = require("./tickets.json");

let claimedCategory, unclaimedCategory, winemoji, macemoji, iosemoji;
client.on("ready", async () => {
  console.log(
    `\x1b[32m🤖 Bot is ready, now initializing text channels. Logged in as ${client.user.tag}\x1b[0m`
  );

  let guild = client.guilds.cache.get(config.guild);
  let channels = guild.channels;
  let emojis = guild.emojis;

  claimedCategory =
    channels.cache.find((c) => c.name.match("ASSIGNED")) ||
    (await channels.create("ASSIGNED", { type: "GUILD_CATEGORY" }));
  unclaimedCategory =
    channels.cache.find((c) => c.name.match("UNASSIGNED")) ||
    (await channels.create("UNASSIGNED", { type: "GUILD_CATEGORY" }));

  winemoji =
    emojis.cache.find((emoji) => emoji.name === "windows") ||
    (await emojis.create("./images/windows.png", "windows"));
  macemoji =
    emojis.cache.find((emoji) => emoji.name === "mac") ||
    (await emojis.create("./images/mac.png", "mac"));
  iosemoji =
    emojis.cache.find((emoji) => emoji.name === "ios") ||
    (await emojis.create("./images/ios.png", "ios"));

  if (process.argv[2] == "reset") {
    // reset tickets.json and channels
    console.log("Resetting tickets.json and channels");

    // Push tickets empty to perform
    tickets = {};
    fs.writeFileSync("./tickets.json", "{}");

    // Clear claimed categories
    await claimedCategory.children.forEach((channel) => channel.delete());
    await unclaimedCategory.children.forEach((channel) => channel.delete());

    await client.destroy();
    return process.exit(1);
    //return process.exit();
  }
  //claimedCategory.children.forEach(channel => channel.delete())

  await request(
    {
      url: "https://script-ware.com/api/me",
      credentials: "include",
      headers: defaultHeaders,
      referrer: "https://dashboard.script-ware.com/",
      method: "GET",
      mode: "cors",
      secureOptions: constants.SSL_OP_NO_TLSv1_2,
    },
    (error, response, body) => {
      if (!response || response.statusCode != 200)
        return console.log(`  ⮑ Error during fetch, response: ${body}`);

      try {
        let body_parsed = JSON.parse(body);
        if (!body_parsed.data || !body_parsed.data.username) {
          console.log("Invalid cookie received");
          return process.exit(1);
        } else {
          console.log(
            "\x1b[32m🔑 Logged in as " + body_parsed.data.username + "!\x1b[0m"
          );
        }
      } catch (e) {
        console.log(
          "\x1b[31m⚠ An invalid Dashboard cookie was provided!\x1b[0m"
        );
        return process.exit(1);
      }
    }
  );

  let assignedOptions = {
    url: "https://script-ware.com/api/staff/tickets/assigned",
    //json: true,
    secureOptions: constants.SSL_OP_NO_TLSv1_2,
    headers: defaultHeaders,
    body: '{"last":0}',
    method: "POST",
  };
  let unassignedOptions = {
    url: "https://script-ware.com/api/staff/tickets/all",
    //json: true,
    secureOptions: constants.SSL_OP_NO_TLSv1_2,
    headers: defaultHeaders,
    body: '{"last":0,"unassigned":true}',
    method: "POST",
  };

  async function assigned_callback(error, response, body) {
    if (error) console.log(error);
    if (!response || response.statusCode != 200)
      return console.log(`  ⮑ Error during fetch, response: ${body}`);

    //claimedCategory.setName("ASSIGNED ⛔");
    //console.log(body)

    // get rid of channels that are resolved/closed tickets
    let data = JSON.parse(body);

    let ids = {};
    for (let i = 0; i < data.data.length; i++) {
      ids[data.data[i].id] = "still exists";
    }

    for await (const [k, v] of Object.entries(tickets)) {
      let channel = channels.cache.find((c) => c.name == k.toString());
      if (channel && ids[k] == undefined) {
        console.log(
          `❌ Ticket ${k} is no longer assigned to you, deleting channel`
        );
        channel.delete();
        delete tickets[k];
      }
    }

    // loop through fetched tickets and create channels for them (or add to existing channels)
    try {
      claimedCategory.setName(`ASSIGNED (${data.data.length})`);
    } catch (err) {
      console.log(err);
    }
    for (let i = 0; i < data.data.length; i++) {
      let logo =
        (data.data[i].is_w && `<:windows:${winemoji.id}>`) ||
        (data.data[i].is_m && `<:mac:${macemoji.id}>`) ||
        (data.data[i].is_i && `<:ios:${iosemoji.id}>`) ||
        "";

      let channel = channels.cache.find(
        (c) => c.name == data.data[i].id.toString()
      );
      if (channel) {
        // channel already exists, update it instead of creating a new one
        var ticketFetchOptions = {
          url: `https://script-ware.com/api/staff/tickets/${data.data[i].id}`,
          secureOptions: constants.SSL_OP_NO_TLSv1_2,
          headers: defaultHeaders,
          method: "GET",
        };

        request(ticketFetchOptions, (_, response, body) => {
          if (!response || response.statusCode != 200)
            return console.log(`  ⮑ Error during fetch, response: ${body}`);

          let data2 = JSON.parse(body);
          // see if any new messages have been added
          console.log(`Checking for new messages in ${data.data[i].id}...`);

          if (!tickets[data.data[i].id]) {
            tickets[data.data[i].id] = [];
            channels.cache
              .find((c) => c.name == data.data[i].id.toString())
              .messages.fetch({ limit: 100 })
              .then((messages) => {});
          }

          if (data2.messages.length != tickets[data.data[i].id].length) {
            // messages have been added/removed because the length is not equal
            console.log(
              `  ⮑  New message(s) found in ${data.data[i].id}! Sending... ✅`
            );
            let newmessages = data2.messages
              .reverse()
              .slice(tickets[data.data[i].id].length);
            for (let j = 0; j < newmessages.length; j++) {
              var new_message_data = newmessages[j];
              let msgembed = new MessageEmbed()
                .setAuthor({
                  name:
                    new_message_data.created_by +
                    (new_message_data.staff ? " 🛠️" : ""),
                  iconURL: new_message_data.avatar,
                })
                .setDescription(strip_tags(new_message_data.message))
                .setColor(new_message_data.staff ? "#fcb603" : "#0099ff")
                .setTimestamp(fmt_time(new_message_data.created_at));
              channel.send({ embeds: [msgembed] });

              if (config.ghostPingOnNewMessage)
                channel
                  .send(`<@${config.user}> New message in ${data.data[i].id}`)
                  .then((msg) => msg.delete({ timeout: 1000 }));
            }

            tickets[data.data[i].id] = data2.messages;
            fs.writeFileSync("./tickets.json", JSON.stringify(tickets));
          } else
            console.log(`  ⮑  No new messages found in ${data.data[i].id}. ➖`);
        });
        await sleep(1500);
      } else {
        channels
          .create(data.data[i].id.toString(), {
            parent: claimedCategory,
            topic: `${logo} || ${data.data[i].subject}`,
            position: i,
          })
          .then(async (channel) => {
            let titleEmbed = new MessageEmbed()
              .setTitle(data.data[i].subject)
              .setColor("#4f617d")
              .addFields(
                { name: "Status", value: data.data[i].status, inline: true },
                { name: "Platform", value: logo, inline: true },
                {
                  name: "Updated",
                  value: `<t:${fmt_time(data.data[i].updated_at, true)}:R>`,
                  inline: true,
                },
                {
                  name: "Ticket",
                  value: `[Click to open Dashboard](https://dashboard.script-ware.com/staff?ticket=${data.data[i].id})`,
                  inline: true,
                }
              )
              .setFooter({ text: `${data.data[i].category}` })
              .setTimestamp(fmt_time(data.data[i].updated_at));
            channel
              .send({ embeds: [titleEmbed] })
              .then(async (msg) => await msg.pin()); // info embed

            var ticketFetchOptions = {
              url: `https://script-ware.com/api/staff/tickets/${data.data[i].id}`,
              secureOptions: constants.SSL_OP_NO_TLSv1_2,
              headers: defaultHeaders,
              method: "GET",
            };

            await request(
              ticketFetchOptions,
              await async function (error, response, body) {
                if (!response || response.statusCode != 200)
                  return console.log(
                    `  ⮑ Error during fetch, response: ${body}`
                  );

                let data2 = JSON.parse(body);
                if (!data2) return;

                let data2_ticket = data2.ticket;

                let initialembed = new MessageEmbed()
                  .setAuthor({
                    name: data2_ticket.created_by,
                    iconURL: data2_ticket.avatar,
                  })
                  .setDescription(strip_tags(data2_ticket.description))
                  .setColor("#0099ff")
                  .setTimestamp(fmt_time(data2_ticket.updated_at) || 0); // Why doesn't the first message have a created_at timestamp? LUCI MOMENT!!!
                channel.send({ embeds: [initialembed] });

                for (let i = data2.messages.length - 1; i > -1; i--) {
                  let msgembed = new MessageEmbed()
                    .setAuthor({
                      name:
                        data2.messages[i].created_by +
                        (data2.messages[i].staff ? " 🛠️" : ""),
                      iconURL: data2.messages[i].avatar,
                    })
                    .setDescription(strip_tags(data2.messages[i].message))
                    .setColor(data2.messages[i].staff ? "#fcb603" : "#0099ff")
                    .setTimestamp(fmt_time(data2.messages[i].created_at));
                  channel.send({ embeds: [msgembed] });
                }

                tickets[data.data[i].id] = data2.messages;
              }
            );

            await sleep(1500);
            await fs.writeFileSync("./tickets.json", JSON.stringify(tickets));
          });
      }

      //await sleep(1500);
      //break;
    }

    //claimedCategory.setName('ASSIGNED');
  }
  async function unassigned_callback(_, response, body) {
    if (!response || response.statusCode != 200)
      return console.log(`  ⮑ Error during fetch, response: ${body}`);

    //unclaimedCategory.setName("UNASSIGNED ⛔");
    let data = JSON.parse(body);
    if (!data.data) return;

    // delete tickets that are no longer unclaimed
    let stillUnclaimed = [];
    for (let i = 0; i < data.data.length; i++)
      stillUnclaimed.push(data.data[i].id.toString());

    channels.cache.forEach(async (channel) => {
      if (channel.parent && channel.parent == unclaimedCategory) {
        if (!stillUnclaimed.includes(channel.name)) {
          console.log(
            `Deleting ${channel.name} because it is no longer unclaimed...`
          );
          await channel.delete();
        }
      }
    });

    // loop through fetched tickets and create channels for them (or add to existing channels)
    for (let i = 0; i < data.data.length; i++) {
      let logo =
        (data.data[i].is_w && `<:windows:${winemoji.id}>`) ||
        (data.data[i].is_m && `<:mac:${macemoji.id}>`) ||
        (data.data[i].is_i && `<:ios:${iosemoji.id}>`) ||
        "";
      let channel = channels.cache.find(
        (c) => c.name == data.data[i].id.toString()
      );

      if (!channel) {
        channels
          .create(data.data[i].id.toString(), {
            parent: unclaimedCategory,
            topic: `${logo} ${data.data[i].subject}`,
            position: i,
          })
          .then(async (channel) => {
            let titleEmbed = new MessageEmbed()
              .setTitle(data.data[i].subject)
              .setColor("#4f617d")
              .addFields(
                { name: "Status", value: data.data[i].status, inline: true },
                { name: "Platform", value: logo, inline: true },
                {
                  name: "Updated",
                  value: `<t:${fmt_time(data.data[i].updated_at, true)}:R>`,
                  inline: true,
                },
                {
                  name: "Ticket",
                  value: `[Click to open Dashboard](https://dashboard.script-ware.com/staff?ticket=${data.data[i].id})`,
                  inline: true,
                }
              )
              .setFooter({ text: `${data.data[i].category}` })
              .setTimestamp(fmt_time(data.data[i].updated_at));
            channel
              .send({ embeds: [titleEmbed] })
              .then(async (msg) => await msg.pin()); // info embed

            await request(
              {
                url: `https://script-ware.com/api/staff/tickets/${data.data[i].id}`,
                secureOptions: constants.SSL_OP_NO_TLSv1_2,
                headers: defaultHeaders,
                method: "GET",
              },
              async (error, response, body) => {
                let data2 = JSON.parse(body);
                if (data2.success) {
                  let initialembed = new MessageEmbed()
                    .setAuthor({
                      name: data2.ticket.created_by,
                      avatar: data2.ticket.avatar,
                    })
                    .setDescription(strip_tags(data2.ticket.description))
                    .setColor("#0099ff")
                    .setTimestamp(fmt_time(data2.ticket.updated_at) || 0); // Why doesn't the first message have a created_at timestamp? LUCI MOMENT!!!
                  channel.send({ embeds: [initialembed] });

                  let newmessages = data2.messages;
                  for (let j = 0; j < newmessages.length; j++) {
                    let new_message_data = newmessages[j];
                    let msgembed = new MessageEmbed()
                      .setAuthor({
                        name:
                          new_message_data.created_by +
                          (new_message_data.staff ? " 🛠️" : ""),
                        iconURL: new_message_data.avatar,
                      })
                      .setDescription(strip_tags(new_message_data.message))
                      .setColor(new_message_data.staff ? "#fcb603" : "#0099ff")
                      .setTimestamp(fmt_time(new_message_data.created_at));
                    channel.send({ embeds: [msgembed] });
                  }
                }
              }
            );
          });
      }
    }

    try {
      unclaimedCategory.setName(`UNASSIGNED (${data.data.length})`);
    } catch (err) {
      console.log(err);
    }
    //unclaimedCategory.setName('UNASSIGNED');
  }

  await request(assignedOptions, await assigned_callback);
  await request(unassignedOptions, await unassigned_callback);

  setInterval(async () => {
    console.log("🦴 Fetching tickets...");
    await request(assignedOptions, await assigned_callback);
    await request(unassignedOptions, await unassigned_callback);
  }, FETCH_AWAIT);

  const rest = new REST({ version: "10" }).setToken(config.discordBotToken);
  (async () => {
    try {
      console.log(
        `Started refreshing ${commands.length} application (/) commands.`
      );

      const data = await rest.put(
        Routes.applicationGuildCommands(client.user.id, config.guild),
        { body: commands }
      );

      console.log(
        `Successfully reloaded ${data.length} application (/) commands.`
      );
    } catch (error) {
      console.error(error);
    }
  })();
});

client.on("interactionCreate", async (interaction) => {
  if (!interaction.isCommand()) return;
  if (interaction.guild.id != config.guild) return;
  if (!interaction.member || interaction.member.id != config.user) return;

  const command = client.commands.get(interaction.commandName);
  if (!command)
    return interaction?.reply({
      content: "This command does not exist!",
      ephemeral: true,
    });

  const string = interaction.options.getString("input");
  //console.log({ string, boolean, user, member, channel, role, integer, number, mentionable, attachment });

  let args = [string];

  try {
    await command.execute(
      interaction,
      args,
      defaultHeaders,
      tickets,
      claimedCategory,
      unclaimedCategory,
      strip_tags
    );
    try {
      await interaction.reply({
        content: "Command successful!",
        ephemeral: true,
      });
    } catch (err) {
      console.log(err);
    }
  } catch (error) {
    console.error(error);
    await interaction.reply({
      content: "There was an error while executing this command!",
      ephemeral: true,
    });
  }
});

// TODO: Implement interactions for the support member to use instead as messageCreate is unreliable and doesn't show syntax for each command.
client.on("messageCreate", async (message) => {
  // Only allow User and Guild to be preset one in config
  if (message.author.id != config.user) return;
  if (message.guild.id != config.guild) return;

  // Delete message if found
  if (message.type === "PINS_ADD" && message.author.id == client.user.id)
    setTimeout(() => message.delete(), 10000);

  // Contain prefix?
  if (!message.content.startsWith(config.prefix)) return;

  let args = message.content.slice(config.prefix.length).trim().split(/ +/g);
  let command = args.shift().toLowerCase();
  try {
    switch (command) {
      case "actions" || "actions":
        var action = args.shift().toLowerCase();
        await require(`./commands/actions/${action}.js`).execute(
          message,
          args,
          defaultHeaders
        );
        break;
      case "status":
        await require("./commands/status.js").execute(
          message,
          args,
          defaultHeaders
        );
        break;
      case "reply" || "r" || "respond" || "send":
        await require("./commands/reply.js").execute(
          message,
          args,
          defaultHeaders,
          tickets,
          claimedCategory,
          unclaimedCategory,
          strip_tags
        );
        break;
      case "claim":
        await require("./commands/claim.js").execute(
          message,
          args,
          defaultHeaders,
          tickets,
          claimedCategory,
          unclaimedCategory,
          strip_tags
        );
        break;
      default:
        break;
    }
  } catch (e) {
    console.log(`\x1b[33mThere was an error executing ${command}: \x1b[0m${e}`);
  }
});

client.login(config.discordBotToken);
