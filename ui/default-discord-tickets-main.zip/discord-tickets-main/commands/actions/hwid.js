const request = require("request");
const constants = require("constants");
const Discord = require("discord.js");

exports.execute = async (message, args, defaultHeaders) => {
  request.post(
    {
      form: { id: parseInt(message.channel.name) },
      url: "https://script-ware.com/api/staff/tickets/actions/hwid",
      secureOptions: constants.SSL_OP_NO_TLSv1_2,
      headers: defaultHeaders,
    },
    function callback(error, response, body) {
      if (error) console.log(error.stringify());
      if (JSON.parse(body).success) {
        let initialembed = new Discord.MessageEmbed()
          .setDescription("The customer's HWID has been reset.")
          .setColor("#4f617d");
        message.channel.send({ embeds: [initialembed] });
      }
    }
  );
};
