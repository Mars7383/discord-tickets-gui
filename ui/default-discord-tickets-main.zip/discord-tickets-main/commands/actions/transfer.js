/* eslint-disable no-unused-vars */
const request = require("request");
const constants = require("constants");
const { SlashCommandBuilder } = require('@discordjs/builders'); // v13
const { MessageEmbed } = require("discord.js");

module.exports = {
  async execute(message, args, defaultHeaders /*/, tickets, claimedCategory/*/) {
    //console.log(args);
    //console.log(message.channel.name);
    request.post({
      form: { id: parseInt(message.channel.name), transfer_to: args[0] },
      url: "https://script-ware.com/api/staff/tickets/actions/transfer",
      secureOptions: constants.SSL_OP_NO_TLSv1_2,
      headers: defaultHeaders,
    }, function callback(error, response, body) {
      if (error) console.log(error.stringify());
      if (JSON.parse(body).success) {
        let initialembed = new MessageEmbed()
          .setDescription(`The ticket has been transferred to ${args[0]}.`)
          .setColor("#4f617d");
        message.channel.send({ embeds: [initialembed] });
      }
    });
  }
}
