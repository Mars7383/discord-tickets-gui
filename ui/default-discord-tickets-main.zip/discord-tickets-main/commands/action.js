const request = require("request");

const { SlashCommandBuilder } = require('@discordjs/builders'); // v13
const { MessageEmbed } = require("discord.js");

// Interaction only:tm:

module.exports = {
  data: new SlashCommandBuilder()
    .setName("action")
    .setDescription("Peforms ticket action.")
    .addStringOption(option =>
      option.setName('input')
        .setDescription('Set status of ticket.')
        .setRequired(true)
        .addChoices(
          { name: 'reset_hwid', value: 'hwid' },
          { name: 'transfer', value: 'transfer' },
          { name: 'leave', value: 'leave' },
        ))
    .addStringOption(option =>
      option.setName('args')
        .setDescription('n/a')
        .setRequired(false)),
  async execute(interaction, _, defaultHeaders, tickets, claimedCategory) {
    let args = interaction.options.getString('args')?.trim().split(/ +/g)
    let action = interaction.options.getString('input')

    await require(`./actions/${action}.js`).execute(interaction, args, defaultHeaders);
  }
}