const request = require("request");
const constants = require("constants");
const { SlashCommandBuilder } = require('@discordjs/builders'); // v13
const { MessageEmbed } = require("discord.js");
const fs = require("fs");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("reply")
    .setDescription("Replies to current ticket you are viewing.")
    .addStringOption(option =>
      option.setName('input')
        .setDescription('Replying message.')
        .setRequired(true)),
  async execute(
    message,
    args,
    defaultHeaders,
    tickets,
    claimedCategory,
    unClaimedCategory,
    strip_tags
  ) {
    if (message.channel.parent == unClaimedCategory)
      return message.reply({ content: "This ticket is unclaimed, you may want to claim it!", ephemeral: true });

    request.post(
      {
        form: { id: parseInt(message.channel.name), message: args.join(" ") },
        url: "https://script-ware.com/api/staff/tickets/actions/reply",
        secureOptions: constants.SSL_OP_NO_TLSv1_2,
        headers: defaultHeaders,
      },
      function callback(error, response, body) {
        if (error) console.log(error.stringify());
        if (JSON.parse(body).success) {
          message?.delete?.();

          let channel = message.channel;
          request(
            {
              url: `https://script-ware.com/api/staff/tickets/${parseInt(
                message.channel.name
              )}`,
              secureOptions: constants.SSL_OP_NO_TLSv1_2,
              headers: defaultHeaders,
              method: "GET",
            },
            function callback(error, response, body) {
              let data2 = JSON.parse(body);
              let newmessages = data2.messages
                .reverse()
                .slice(tickets[parseInt(message.channel.name)].length);
              for (let j = 0; j < newmessages.length; j++) {
                let msgembed = new MessageEmbed()
                  .setAuthor({
                    name:
                      newmessages[j].created_by +
                      (newmessages[j].staff ? " 🛠️" : ""),
                    iconURL: newmessages[j].avatar,
                  })
                  .setDescription(strip_tags(newmessages[j].message)) // we remove markdown from the text
                  .setColor(newmessages[j].staff ? "#fcb603" : "#0099ff")
                  .setTimestamp(newmessages[j].created_at);
                channel.send({ embeds: [msgembed] });
              }

              tickets[parseInt(message.channel.name)] = data2.messages;
              fs.writeFileSync("./tickets.json", JSON.stringify(tickets));
            }
          );
        }
      }
    );
  },
};
