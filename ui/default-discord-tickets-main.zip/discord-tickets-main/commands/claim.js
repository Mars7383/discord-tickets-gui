const request = require("request");
const constants = require("constants");
const { SlashCommandBuilder } = require('@discordjs/builders'); // v13
const { MessageEmbed } = require("discord.js");
const fs = require("fs");


module.exports = {
  data: new SlashCommandBuilder()
    .setName("claim")
    .setDescription("Claims the current ticket you are viewing"),
  async execute(message, args, defaultHeaders, tickets, claimedCategory, unclaimedCategory, strip_tags) {
    request.post(
      {
        form: { id: parseInt(message.channel.name) },
        url: "https://script-ware.com/api/staff/tickets/actions/claim",
        secureOptions: constants.SSL_OP_NO_TLSv1_2,
        headers: defaultHeaders,
      },
      async function callback(error, response, body) {
        if (error) console.log(error.stringify());
        if (JSON.parse(body).success) {
          try {
            message?.delete?.();
          } catch (e) { }

          await message.channel.setParent(claimedCategory);
          let channel = message.channel;
          request(
            {
              url: `https://script-ware.com/api/staff/tickets/${parseInt(
                message.channel.name
              )}`,
              secureOptions: constants.SSL_OP_NO_TLSv1_2,
              headers: defaultHeaders,
              method: "GET",
            },
            async function callback(error, response, body) {
              let data2 = JSON.parse(body);
              let channelMessages = await channel.messages.fetch({ limit: 10 });

              let filtered = channelMessages.filter(
                (msg) => msg.author.id == message.client.user.id
              );
              if (filtered.length < 2) {
                let initialembed = new MessageEmbed()
                  .setAuthor({
                    name: data2.ticket.created_by,
                    iconURL: data2.ticket.avatar,
                  })
                  .setDescription(strip_tags(data2.ticket.description)) // we remove markdown from the text
                  .setColor("#0099ff");
                //.setTimestamp(data2.ticket.updated_at) // Why doesn't the first message have a created_at timestamp? LUCI MOMENT!!!
                channel.send(initialembed);
              }

              let newmessages = data2.messages;
              for (let j = 0; j < newmessages.length; j++) {
                let msgembed = new MessageEmbed()
                  .setAuthor({
                    name:
                      newmessages[j].created_by +
                      (newmessages[j].staff ? " 🛠️" : ""),
                    iconURL: newmessages[j].avatar,
                  })
                  .setDescription(strip_tags(newmessages[j].message)) // we remove markdown from the text
                  .setColor(newmessages[j].staff ? "#fcb603" : "#0099ff")
                  .setTimestamp(newmessages[j].created_at);
                channel.send({ embeds: [msgembed] });
              }
              tickets[parseInt(message.channel.name)] = data2.messages;
              fs.writeFileSync("./tickets.json", JSON.stringify(tickets));
              try {
                unclaimedCategory.setName(`UNASSIGNED (${unclaimedCategory.children.size})`)
              } catch (err) {
                console.log(err)
              }
            }
          );
        }
      }
    );
  },
};