const request = require("request");
const constants = require("constants");
const { SlashCommandBuilder } = require('@discordjs/builders'); // v13
const { MessageEmbed } = require("discord.js");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("status")
    .setDescription("Sets status of ticket.")
    .addStringOption(option =>
      option.setName('input')
        .setDescription('Set status of ticket.')
        .setRequired(true)
        .addChoices(
          { name: 'open', value: 'open' },
          { name: 'closed', value: 'closed' },
          { name: 'resolved', value: 'resolved' },
          { name: 'under_review', value: 'Under Review' }
        )),
  async execute(
    message,
    args,
    defaultHeaders,
    tickets,
    claimedCategory,
    unClaimedCategory
  ) {
    //console.log(message.options);
    // Capitalize the first letter of all words, leave everything else lowercase (luci moment)
    if (message?.options) {
      args = message.options.getString('input')?.trim().split(/ +/g).map(
        (arg) => arg.charAt(0).toUpperCase() + arg.slice(1).toLowerCase()
      );
    } else {
      args = args.map(
        (arg) => arg.charAt(0).toUpperCase() + arg.slice(1).toLowerCase()
      );
    }

    request.post(
      {
        form: { id: parseInt(message.channel.name), status: args.join(" ") },
        url: "https://script-ware.com/api/staff/tickets/update/status",
        secureOptions: constants.SSL_OP_NO_TLSv1_2,
        headers: defaultHeaders,
      },
      function callback(error, response, body) {
        if (error) console.log(error.stringify());
        if (JSON.parse(body).success) {
          let initialembed = new MessageEmbed()
            .setDescription(
              `Updated status to ${args.join(
                " "
              )}. This channel will be deleted soon if the ticket is no longer assigned to you.`
            )
            .setColor("#4f617d");
          message.channel.send({ embeds: [initialembed] });
        } else {
          console.log(body);
          console.log(args.join(" "));
        }
      }
    );
  },
};
