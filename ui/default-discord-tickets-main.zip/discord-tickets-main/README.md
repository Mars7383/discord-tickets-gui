# Script-Ware ticket bot (by Mars7383 and fxe)
A bot for handling the onsite ticket system on the [dashboard](https://dashboard.script-ware.com/) of [Script-Ware](https://script-ware.com)
# Setup guide

1. Install [Node.JS](https://nodejs.org/en/download/) (or: [scoop](https://scoop.sh/) install nodejs)
2. Edit the `config.json` file with the according information for your Script-Ware staff account
3. Open your specified Terminal/CMD instance on the Script-Ware ticket bot folder (Right click the Explorer(Shift+Right Click)/Finder or navigate to your folders path using `cd`)
4. Use the following commands:
5. `npm i`
6. `npm i -g forever`
7. `forever .` 
8. Done! (Want to rerun the bot? Do step 3, then do `forever .` again, or... `node .`)
